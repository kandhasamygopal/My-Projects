package StepDefinations;

import java.sql.DriverManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;
import whaot_constants.Constants;
import whaot_utilitiles.CommonUtils;

public class Whaot_Common_Step_Definations {
	
	private static String scenarioName=null;
	
	//Launch Browser
	
	 
	 
	 public static String getScenarioName() {
		return scenarioName;
	}


	private static final Logger LOGGER=LogManager.getLogger(Whaot_Common_Step_Definations.class);
	
	
	@Before
	public void Beforescenario(Scenario scenario) {
	
        LOGGER.info("Execution started");
		
		try {
			scenarioName= scenario.getName();

			LOGGER.info("instantiation of commonutils");
			
			LOGGER.info("loading the properties files");
			CommonUtils.getInstance().loadproperties();
			LOGGER.info("Checking the Driver is NULL OR NOT");
			if(whaot_webdriver_manager.DriverManager.getDriver()==null) {
		    LOGGER.info("Driver is NULL.Instantiating it!");	
		    whaot_webdriver_manager.DriverManager.lanuchBrowser();
		    CommonUtils.getInstance().initWebElements();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		
	}


}
	
	
	
	
	
	
	


