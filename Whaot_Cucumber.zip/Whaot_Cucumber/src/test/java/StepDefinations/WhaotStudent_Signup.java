package StepDefinations;

import java.awt.Window;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import whaot.locators.StudentSignup_Locators;
import whaot_constants.Constants;
import whaot_utilitiles.CommonUtils;
import whaot_webdriver_manager.DriverManager;

public class WhaotStudent_Signup {

	
	
	
	
	private static final Logger LOGGER=LogManager.getLogger(WhaotStudent_Signup.class);
	
	@Given("Enter the whaot application URL")
	public void enter_the_whaot_application_url() {
		try {
			DriverManager.getDriver().get(Constants.APPLICATION_URL);
			DriverManager.getDriver().manage().window().maximize();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
		

	}

	@Given("Click the Login signup button")
	public void click_the_login_signup_button() throws Throwable {
		
		try {
			Thread.sleep(1000);
			StudentSignup_Locators.getInstance().Signup_button();
		} catch (Exception e) {
		   LOGGER.error(e);
		   CommonUtils.getInstance().takeScreenshot();
		}
		
		

	}

	@When("^Enter the student phonenumber (.*)$")
	public void Enter_the_student_phonenumber(String phonenumber) throws Throwable {
		try {
			Thread.sleep(3000);
			StudentSignup_Locators.getInstance().getNewuserphonenumber(phonenumber);
			
			
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
		
	}
	@When("Click the student proceed button")
	public void click_the_student_proceed_button() {
		try {
			StudentSignup_Locators.getInstance().ProceedButton();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();

		}
		
	}
	
	

	@When("Choose the startlearning option")
	public void choose_the_startlearning_option() throws Throwable {
		try {
			Thread.sleep(2000);
			StudentSignup_Locators.getInstance().ClickStartlearning();
			
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
		
		
	}

	@When("^Enter the student Full name (.*)$")

	public void enter_the_student_full_name_testuser_automation(String studentname) throws InterruptedException {
		
		try {
			Thread.sleep(1000);
			StudentSignup_Locators.getInstance().Enter_StudentName(studentname);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
		
		

	}

	@When("^Enter the student email id (.*)$")
	public void enter_the_student_email_idautomation_tofeat_com(String studentemail) {
		try {
			StudentSignup_Locators.getInstance().EnterStudent_Email(studentemail);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
		
	}

//	@When("^IF user have a coupon enter the coupon code (.*)")
//	public void if_user_have_a_coupon_enter_the_coupon_code() {
//
//	}

	@When("^enter the password (.*)$")
	public void enter_the_password123456(String password) throws InterruptedException {
		
		try {
			String parentwindow=DriverManager.getDriver().getWindowHandle();
			
			
			Thread.sleep(2000);
			
			JavascriptExecutor js1=(JavascriptExecutor)DriverManager.getDriver().switchTo().window(parentwindow);
		        js1.executeScript("window.scrollBy (0,200)", "");
		        
			StudentSignup_Locators.getInstance().EnterStudent_Password(password);
			
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
		
	}

	@When("click the Register button")
	public void click_the_register_button() {
		try {
			StudentSignup_Locators.getInstance().Register_Student();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}



	}
	@When("^enter the Student signin OTP1 number (.*)$")
	public void enter_the_student_signin_otp1_number(String OTP1) {
		try {
			Thread.sleep(1000);
			StudentSignup_Locators.getInstance().Verify_OTP1(OTP1);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
	}
	@When("^enter the Student signin OTP2 number (.*)$")
	public void enter_the_student_signin_otp2_number(String OTP2) {
		try {
			StudentSignup_Locators.getInstance().Verify_OTP2(OTP2);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
	    
	}
	@When("^enter the Student signin OTP3 number (.*)$")
	public void enter_the_student_signin_otp3_number(String OTP3) {
		try {
			StudentSignup_Locators.getInstance().Verify_OTP3(OTP3);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
	   
	}
	@When("^enter the Student signin OTP4 number (.*)$")
	public void enter_the_student_signin_otp4_number(String OTP4) {
		try {
			StudentSignup_Locators.getInstance().Verify_OTP4(OTP4);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
	    
	}



	
	@Then("user choose interest page select the three interest")
	public void user_choose_interest_page_select_the_three_interest() throws Throwable {
	
	try {
//		StudentSignup_Locators.getInstance().chosseinterest1();
//		StudentSignup_Locators.getInstance().chosseinterest2();
//	    StudentSignup_Locators.getInstance().chosseinterest3();
//    	StudentSignup_Locators.getInstance().saveandProceed();
		
	} catch (Exception e) {
		LOGGER.error(e);
		CommonUtils.getInstance().takeScreenshot();
	}
				
		
		
		
		
		
		
		
		
		
		
	}
	


}
