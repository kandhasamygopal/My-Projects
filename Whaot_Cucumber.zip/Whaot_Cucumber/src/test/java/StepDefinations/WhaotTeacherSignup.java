package StepDefinations;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import whaot.locators.SignupPageLocators;
import whaot.locators.TeacherSignup_Locators;
import whaot_constants.Constants;
import whaot_utilitiles.CommonUtils;
import whaot_webdriver_manager.DriverManager;

public class WhaotTeacherSignup {

	private static final Logger LOGGER=LogManager.getFormatterLogger(WhaotTeacherSignup.class);


	@Given("Enter the whaot application teacher URL")
	public void enter_the_whaot_application_url() {
		try {
			DriverManager.getDriver().get(Constants.APPLICATION_URL);
			DriverManager.getDriver().manage().window().maximize();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}

	@Given("Click the Login teacher signup button")
	public void click_the_login_signup_button() throws Throwable {
		try {
			Thread.sleep(1000);
			TeacherSignup_Locators.getinstance().Signup_button();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}


	@When("^Enter the teacher phonenumber (.*)$")
	public void enter_the_teacher_phonenumber(String phonenumber) throws InterruptedException {

		try {
			Thread.sleep(1000);
			TeacherSignup_Locators.getinstance().Newteacherphonenumber(phonenumber);

		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}
	@When("Click the teacher proceed button")
	public void click_the_teacher_proceed_button() {

		try {
			TeacherSignup_Locators.getinstance().ProceedButton();	
			LOGGER.info("click the proceed to button");
		}
		catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
	}
	
	@When("Choose the Become a guru option")
	public void choose_the_become_a_guru_option() throws InterruptedException {
		try {
			Thread.sleep(1000);
			TeacherSignup_Locators.getinstance().Become_Guru();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}
	@When("^Enter the Teacher Full name (.*)$")
	public void enter_the_teacher_full_name_elangoram(String teachername) throws InterruptedException {
		try {
			Thread.sleep(1000);
			TeacherSignup_Locators.getinstance().Enter_TeacherName(teachername);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}
	@When("^Enter the Teacher email id (.*)$")
	public void enter_the_teacher_email_id_elanoram_tofeat_com(String teacheremail) {
		try {
			TeacherSignup_Locators.getinstance().Enterteacher_Email(teacheremail);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}

	@When("^enter the teacher password (.*)$")
	public void enter_the_password123456(String teacherpassword) throws InterruptedException {
		try {
			TeacherSignup_Locators.getinstance().getEnterStudent_Password(teacherpassword);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}

	@When("click the teacher Register button")
	public void click_the_teacher_register_button() throws InterruptedException {
		try {
			TeacherSignup_Locators.getinstance().Register_Teacher();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}




	}

	@Then("user successfully login the to be show the profile verification page")
	public void user_successfully_login_the_to_be_show_the_profile_verification_page() throws InterruptedException {
		try {
			TeacherSignup_Locators.getinstance().Submit();

		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}













}
