package StepDefinations;

import java.time.Duration;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.checkerframework.checker.formatter.qual.Format;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.it.Date;
import whaot.locators.StudentBookingclassLocators;
import whaot_utilitiles.CommonUtils;
import whaot_webdriver_manager.DriverManager;

public class Whaot_StudentBookingclass_StepDefinations {


	private static final Logger LOGGER=LogManager.getFormatterLogger(Whaot_StudentBookingclass_StepDefinations.class);


	@Given("student choose the one the schedule class")
	public void student_choose_the_one_the_schedule_class() throws InterruptedException {
		
//		JavascriptExecutor js2=(JavascriptExecutor)DriverManager.getDriver();
//		js2.executeScript("window.scrollBy (0,500)", "");
		try {
			Thread.sleep(10000);
			StudentBookingclassLocators.getInstance().Scheduleclass_click();

		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}

	@Given("click the schedule classs its redirect to booking class page")
	public void click_the_schedule_classs_its_redirect_to_booking_class_page() throws InterruptedException {
		Thread.sleep(2000);
		try {
			//to perform Scroll on application on java
			JavascriptExecutor js3=(JavascriptExecutor)DriverManager.getDriver();
			js3.executeScript("window.scrollBy (0,1200)", "");

		} catch (Exception e) {
				LOGGER.error(e);
				CommonUtils.getInstance().takeScreenshot();
		}
		


	}

	@Given("Student scroll down the page and click the booking class button")
	public void student_scroll_down_the_page_and_click_the_booking_class_button() throws InterruptedException {

		Thread.sleep(2000);
		try {
			StudentBookingclassLocators.getInstance().Book_this_class();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}

	@Given("The schedule class page student student click the add new class slots link")
	public void the_schedule_class_page_student_student_click_the_add_new_class_slots_link() throws InterruptedException {
		try {
			Thread.sleep(3000);
			StudentBookingclassLocators.getInstance().Clickaddnewclass();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}

	@Given("click the pick slot button")
	public void click_the_pick_slot_button() throws InterruptedException {

		try {
			Thread.sleep(1000);
			StudentBookingclassLocators.getInstance().ClickPickslot();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}

	@Given("^student choose the dates(.*)&(.*)the class slots$")
	public void student_choose_the_dates_the_class_slots(String date, String time) throws Throwable {
		try {
			Thread.sleep(3000);
			StudentBookingclassLocators.getInstance().Choosedate(date);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}
		try {
			StudentBookingclassLocators.getInstance().ChoosedateClick();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

		try {
			Thread.sleep(1000);
			StudentBookingclassLocators.getInstance().Choosetime(time);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}

	@Given("Finally click the save the date & time")
	public void finally_click_the_save_the_date_time() throws InterruptedException {
		try {
			Thread.sleep(1000);
			StudentBookingclassLocators.getInstance().Savedatetime();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}

	@Then("page navigate to Review your booking page")
	public void page_navigate_to_review_your_booking_page() throws InterruptedException {
		try {
			Thread.sleep(1000);
			StudentBookingclassLocators.getInstance().ReviewBooking();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}

	@Then("Click the procedd to pay")
	public void click_the_procedd_to_pay() throws InterruptedException {
		try {
			Thread.sleep(1000);
			JavascriptExecutor js3=(JavascriptExecutor)DriverManager.getDriver();
			js3.executeScript("window.scrollBy (0,400)", "");

			StudentBookingclassLocators.getInstance().Proceedtopay();
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}


	}

	@Then("payment should be naviagated")
	public void payment_should_be_naviagated() throws Throwable {

		try {
			WebElement frame= DriverManager.getDriver().findElement(By.xpath("//iframe[@class='razorpay-checkout-frame']"));
			DriverManager.getDriver().switchTo().frame(frame);
			WebDriverWait wait= new WebDriverWait(DriverManager.getDriver(), Duration.ofSeconds(50));



			wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//*[@id='form-common']/div[1]/div[1]/div/div/div[2]/div/button[1]")))).click();

		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}

	@When("choose the card payment and enter the {string} and Expiry {string} and CVV {string}")
	public void choose_the_card_payment_and_enter_the_and_expiry_and_cvv(String string, String string2, String string3) throws InterruptedException {
		try {
			Thread.sleep(1000);
			StudentBookingclassLocators.getInstance().Entercardnumber(string);
			StudentBookingclassLocators.getInstance().CardExpiry(string2);
			StudentBookingclassLocators.getInstance().CVV_Collected(string3);
		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}

	@Then("page naviagate payment page success or failure page")
	public void page_naviagate_payment_page_success_or_failure_page() throws InterruptedException {

		try {
			Thread.sleep(2000);
			WebElement Pay= DriverManager.getDriver().findElement(By.id("redesign-v15-cta"));
			Pay.click();

			Thread.sleep(2000);
			WebElement PayCardskip= DriverManager.getDriver().findElement(By.xpath("//*[@id='overlay']/div/div/button[2]"));
			PayCardskip.click();


		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}

	@Then("Click the success button & finally class will be bookked message show")
	public void click_the_success_button_finally_class_will_be_bookked_message_show() throws Throwable {

		try {
			DriverManager.getDriver().switchTo().defaultContent();	

			Set<String> handles = DriverManager.getDriver().getWindowHandles();


			for (String newwindow : handles) {

				DriverManager.getDriver().switchTo().window(newwindow);

			}
			Thread.sleep(2000);		
			WebElement Success= DriverManager.getDriver().findElement(By.xpath("//*[@class='success']"));
			Success.click();

		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

		//		String parentwindow=  DriverManager.getDriver().getWindowHandle();
		//		DriverManager.getDriver().switchTo().window(parentwindow);
		//	    
	}

	@Then("click the booking class success message OkayButton")
	public void click_the_booking_class_success_message_okay_button() throws Throwable {
		//		DriverManager.getDriver().switchTo().defaultContent();	
		try {
			Thread.sleep(3000);	
			WebElement okay= DriverManager.getDriver().findElement(By.xpath("//*[@id='booking-success-modal']/div/div/div[1]/div/div[2]/button"));
			okay.click();

		} catch (Exception e) {
			LOGGER.error(e);
			CommonUtils.getInstance().takeScreenshot();
		}

	}

	@Then("Finally user will be see the booking class details")
	public void finally_user_will_be_see_the_booking_class_details() {


	}
}
