package StepDefinations;

import java.awt.AWTException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import whaot.locators.TeacherProfile_Locators;
import whaot_webdriver_manager.DriverManager;

public class WhaotTeacherProfile {

	private static final Logger LOGGER=LogManager.getFormatterLogger(WhaotTeacherProfile.class);

	String parentwindow= DriverManager.getDriver().getWindowHandle();
	
	


	@Given("Click the next button to contiune the profile")
	public void click_the_next_button_to_contiune_the_profile() {
		try {
			
			Thread.sleep(15000);
			JavascriptExecutor js1=(JavascriptExecutor)DriverManager.getDriver();
        	js1.executeScript("window.scrollBy (250,1200)", "");
			TeacherProfile_Locators.getInstance().getNextButton();
			
		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@Given("Read the teacher instruction whaot click the Aggree and continue button")
	public void read_the_teacher_instruction_whaot_click_the_aggree_and_continue_button() {
		try {
			Thread.sleep(1000);
			TeacherProfile_Locators.getInstance().getAgreeContinue();
		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@When("Uploaded the teacher profile picture {string}")
	public void uploaded_the_teacher_profile_picture(String teacherphoto) {
		try {
			Thread.sleep(1000);
			TeacherProfile_Locators.getInstance().getUploadphoto(teacherphoto);
			TeacherProfile_Locators.getInstance().CropPhotoUpload();
		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@When("Choose the teacher preferred lanuguage dropdowns")
	public void choose_the_teacher_preferred_lanuguage_dropdowns() {
		try {
			Thread.sleep(1000);
			TeacherProfile_Locators.getInstance().getChooselanuguage();
			List<WebElement> languages=DriverManager.getDriver().findElements(By.xpath("//div[@class=' css-26l3qy-menu']//div[@class=' css-11unzgr']//div"));
			System.out.println("No of options languages:" + languages.size() );
			SelectOptionfromDropdown(languages,"Hindi");
   

		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@When("Click the teacher profile step one continue button")
	public void click_the_teacher_profile_step_one_continue_button() {
		
		try {
			Thread.sleep(1000);
			TeacherProfile_Locators.getInstance().getContinueNext();

		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@And("Enter the Teacher expertise title of specialize")
	public void enter_the_teacher_expertise_title_of_specialize() {
		try {
			Thread.sleep(1000);
			TeacherProfile_Locators.getInstance().getSpecialize();
			
			List<WebElement> SpecializeTopic=DriverManager.getDriver().findElements(By.xpath("//ul[@class='chosen-results']//li"));
			System.out.println("No of SpecializeTopic options:" + SpecializeTopic.size() );
			SelectOptionfromDropdown(SpecializeTopic,"Music");
			 
		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@And("Choose the specialize based Add topics on teacher")
	public void choose_the_specialize_based_add_topics_on_teacher() {
		try {
			Thread.sleep(1000);
			TeacherProfile_Locators.getInstance().AddTopics();
			JavascriptExecutor js7=(JavascriptExecutor)DriverManager.getDriver();
			js7.executeScript("window.scrollBy (0,100)", "");
			Thread.sleep(2000);
			List<WebElement> Topicchoose=DriverManager.getDriver().findElements(By.xpath("//div[@class='tags-inner']//ul/li"));
			System.out.println("No of Topics options:" + Topicchoose.size() );
			SelectOptionfromDropdown(Topicchoose,"Keyboard");


		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@When("Choose the verify your expertise others button and fill the all details {string} and {string} and {string} or uplaoded the document")
	public void choose_the_verify_your_expertise_others_button_and_fill_the_all_details_or_uplaoded_the_document(String addExpertisetitle,String addexpertiseDescription, String addExpertiseURL) {
		try {
			
			JavascriptExecutor js10=(JavascriptExecutor)DriverManager.getDriver();
			js10.executeScript("window.scrollBy (0,300)", "");
			Thread.sleep(3000);
			TeacherProfile_Locators.getInstance().getVerifyexpertise();
			Thread.sleep(1000);
			
			
			DriverManager.getDriver().switchTo().window(parentwindow);
			TeacherProfile_Locators.getInstance().getAddexpertisetitle(addExpertisetitle);
			TeacherProfile_Locators.getInstance().getAddexpertiseDescription(addexpertiseDescription);
			TeacherProfile_Locators.getInstance().getAddExpertiseURL(addExpertiseURL);
			TeacherProfile_Locators.getInstance().getSaveExpertiseDocument();
			
		} catch (Exception e) {
			LOGGER.error(e);

	}
	}
	@When("click the contiune button on teacher profile verification steptwo process after completion")
	public void click_the_contiune_button_on_teacher_profile_verification_steptwo_process_after_completion() {
		try {
			Thread.sleep(1000);
			DriverManager.getDriver().switchTo().window(parentwindow);
			JavascriptExecutor js11=(JavascriptExecutor)DriverManager.getDriver();
			js11.executeScript("window.scrollBy(0,600)", "");
			TeacherProfile_Locators.getInstance().getContinueintrovideouploadedpage();
		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@When("Drag and upload the teacher intro video {string}")
	public void drag_and_upload_the_teacher_intro_video(String string) {
		try {
			Thread.sleep(3000);
			TeacherProfile_Locators.getInstance().getIntroVideo();
			TeacherProfile_Locators.getInstance().IntroVideoloaded60secVideo(string);
			}
		catch (Exception e) {
			
			LOGGER.error(e);
		}

	}
	@When("Click the video verification on teacher identity should be verified")
	public void click_the_video_verification_on_teacher_identity_should_be_verified() {
		try {
			
			JavascriptExecutor js12=(JavascriptExecutor)DriverManager.getDriver();
			js12.executeScript("window.scrollBy(0,600)", "");
			Thread.sleep(2000);
			
			TeacherProfile_Locators.getInstance().getVerifymyidentity();
			DriverManager.getDriver().switchTo().window(parentwindow);
			Thread.sleep(1000);
			TeacherProfile_Locators.getInstance().getTurnONmycamara();
			Thread.sleep(1000);
			TeacherProfile_Locators.getInstance().getRecorderbuttonclick();
            
			
		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@When("Click to the Gobutton and complete the profile")
	public void click_to_the_gobutton_and_complete_the_profile() {
		try {
			Thread.sleep(2000);
			JavascriptExecutor js12=(JavascriptExecutor)DriverManager.getDriver();
			js12.executeScript("window.scrollBy(0,600)", "");
			TeacherProfile_Locators.getInstance().getGoodtogo();
		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	@Then("user teacher successfully complete the profile creation and finally it will by review on the admin.")
	public void user_teacher_successfully_complete_the_profile_creation_and_finally_it_will_by_review_on_the_admin() {
		try {
			Thread.sleep(3000);
			JavascriptExecutor js15=(JavascriptExecutor)DriverManager.getDriver();
			js15.executeScript("window.scrollBy(0,1800)", "");
			TeacherProfile_Locators.getInstance().getFinalreview();
		} catch (Exception e) {
			LOGGER.error(e);
		}

	}
	public static void SelectOptionfromDropdown(List<WebElement> options , String value) throws InterruptedException, AWTException	
	{
		for(WebElement option:options)
		{
			if(option.getText().equals(value))
			{
			}
			option.click();
			break;
		}

	}





}
