package StepDefinations;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import whaot.locators.TeacherScheduleClass_Locators;
import whaot_webdriver_manager.DriverManager;

public class WhaotTeacherScheduleclass {

	private static final Logger LOGGER=LogManager.getFormatterLogger(WhaotTeacherScheduleclass.class);



	@Given("Teacher click the create a class button")
	public void teacher_click_the_create_a_class_button() {
		try {
			Thread.sleep(15000);
			JavascriptExecutor js1=(JavascriptExecutor)DriverManager.getDriver();
			js1.executeScript("window.scrollBy (150,100)", "");
			TeacherScheduleClass_Locators.getInstance().getCreatescheduleclass();

		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("write the class title i will teach you {string}")
	public void write_the_class_title_i_will_teach_you(String string) {
		try {

			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getIwillteachyou(string);
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher choose the category option")
	public void teacher_choose_the_category_option() {
		try {
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getChoosecategory();
		} catch (Exception e) {
			LOGGER.error(e);
		} 
	}
	@When("Teacher choose the topics option")
	public void teacher_choose_the_topics_option() {
		try {
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getSelectedTopics();
		} catch (Exception e) {
			LOGGER.error(e);
		} 

	}
	@When("Teacher upload the video\\/cover option upload the {string} and {string}")
	public void teacher_upload_the_video_cover_option_upload_the_and(String string, String string2) {
		try {
			Thread.sleep(1000);
			JavascriptExecutor js2=(JavascriptExecutor)DriverManager.getDriver();
			js2.executeScript("window.scrollBy(0,500)", "");

			TeacherScheduleClass_Locators.getInstance().getVideocover(string);
			TeacherScheduleClass_Locators.getInstance().getVideothumbinal(string2);
			TeacherScheduleClass_Locators.getInstance().VideothumbinalCropUpload();
		} catch (Exception e) {
			LOGGER.error(e);
		}  
	}
	@When("Teacher select the class level option")
	public void teacher_select_the_class_level_option() {
		try {
			JavascriptExecutor js3=(JavascriptExecutor)DriverManager.getDriver();
			js3.executeScript("window.scrollBy(0,300)", "");
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getSelectlevel();
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher enter the class description details {string} and {string} and {string}")
	public void teacher_enter_the_class_description_details_and_agenda_and(String string, String string2,String string3) {
		try {
			Thread.sleep(2000);
			TeacherScheduleClass_Locators.getInstance().getClassDescription(string);
			TeacherScheduleClass_Locators.getInstance().getAgenda(string2);
			TeacherScheduleClass_Locators.getInstance().getRequirements(string3);
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher Choose the languages dropdown option")
	public void teacher_choose_the_languages_dropdown_option() {
		try {
			JavascriptExecutor js2=(JavascriptExecutor)DriverManager.getDriver();
			js2.executeScript("window.scrollBy(0,700)", "");
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getLanguages();
			List<WebElement> chooselanguage = DriverManager.getDriver().findElements(By.xpath("//div[@class=' css-11unzgr']//div"));
			System.out.println("Number of language:" + chooselanguage.size());
			for(WebElement Ctype:chooselanguage) {
				if(Ctype.getText().equals("Hindi"));{
					Ctype.click();
					break;
				}
			}
			

		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher click the class details continue button")
	public void teacher_click_the_class_details_continue_button() {
		try {
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getContinueNextpage();
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher choose the duration of class")
	public void teacher_choose_the_duration_of_class() {
		try {
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getChooseDuration();

		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher choose the availbilities dates {string} and {string}")
	public void teacher_choose_the_availbilities_dates_and_to_date(String string,String string1) {
		try {
			Thread.sleep(3000);
			TeacherScheduleClass_Locators.getInstance().getAddMoreAvailability();
			TeacherScheduleClass_Locators.getInstance().getFromDate(string);
			TeacherScheduleClass_Locators.getInstance().getToDate(string1);
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher click the selected Days")
	public void teacher_click_the_selected_days() {
		try {
			Thread.sleep(2000);
			TeacherScheduleClass_Locators.getInstance().getSelectMonday();
			TeacherScheduleClass_Locators.getInstance().getSelectTuesday();
			TeacherScheduleClass_Locators.getInstance().getSelectWednesday();
			TeacherScheduleClass_Locators.getInstance().getSelectThursday();
			TeacherScheduleClass_Locators.getInstance().getSelectFriday();
			TeacherScheduleClass_Locators.getInstance().getSelectSaturday();
			TeacherScheduleClass_Locators.getInstance().getSelectSunday();
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher choose the timings include buffer time slots {string} and {string} and {string} and {string} and {string} and {string}")
	public void teacher_choose_the_timings_include_buffer_time_slots_from_time_and(String string,String string1 ,String string3 ,String string4,String string5,String string6) {
		
		try {
			Thread.sleep(3000);
			TeacherScheduleClass_Locators.getInstance().getFromtime();
			TeacherScheduleClass_Locators.getInstance().getTimeslot1(string);
			TeacherScheduleClass_Locators.getInstance().getTimeslot2(string1);
			TeacherScheduleClass_Locators.getInstance().getTimeslot_AM(string3);
			TeacherScheduleClass_Locators.getInstance().getTotime();
            TeacherScheduleClass_Locators.getInstance().getTimeslot3(string4);
			TeacherScheduleClass_Locators.getInstance().getTimeslot4(string5);
			TeacherScheduleClass_Locators.getInstance().getTimeslot_PM(string6);
		
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher choose the pricing details paid class {string} and offer Discounts {string}")
	public void teacher_choose_the_pricing_details_paid_class_and_offer_discounts(String string, String string2) {
		try {
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getClasscharge(string);
			TeacherScheduleClass_Locators.getInstance().getOfferDiscount(string2);
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher click the price availbility continue button click")
	public void teacher_click_the_price_availbility_continue_button_click() {
		try {
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getSecondContiune();
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher click the publish class button class will be published")
	public void teacher_click_the_publish_class_button_class_will_be_published() {
		try {
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getPublishclass();	
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@When("Teacher finally the inactive class button click the active the class")
	public void teacher_finally_the_inactive_class_button_click_the_active_the_class() {
		try {
			Thread.sleep(1000);
			TeacherScheduleClass_Locators.getInstance().getActiveclass();
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	@Then("Teacher finally class will be successfully")
	public void teacher_finally_class_will_be_successfully() {
		try {

		} catch (Exception e) {
			LOGGER.error(e);			}
	}




}
