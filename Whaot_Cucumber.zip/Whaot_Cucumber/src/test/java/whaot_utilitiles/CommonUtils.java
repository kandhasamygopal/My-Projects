package whaot_utilitiles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.core.util.FileUtils;
import org.checkerframework.common.reflection.qual.GetClass;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import StepDefinations.Whaot_Common_Step_Definations;
import whaot.locators.SignupPageLocators;
import whaot.locators.StudentBookingclassLocators;
import whaot.locators.StudentSignup_Locators;
import whaot.locators.TeacherProfile_Locators;
import whaot.locators.TeacherScheduleClass_Locators;
import whaot.locators.TeacherSignup_Locators;
import whaot_constants.Constants;
import whaot_webdriver_manager.DriverManager;

public class CommonUtils {
	
	private static CommonUtils CommonUtilsInstance;
	
	private CommonUtils() {
		
	}
	public static CommonUtils getInstance() {
		
		if(CommonUtilsInstance==null) {
			CommonUtilsInstance=new CommonUtils();
		}
		return CommonUtilsInstance;
		
	}
	

	public void loadproperties() {
		
		Properties  properties= new Properties();	
		try {
			
			properties.load(getClass().getResourceAsStream("/Whaot_configuration.properties"));
			
		} catch (Exception e) {
			e.printStackTrace();
			
			
			// TODO: handle exception
		}
		

		Constants.APPLICATION_URL=properties.getProperty("APPLICATION_URL");
		Constants.BROWSER=properties.getProperty("BROWSER");
		Constants.CHROME_DRIVER_LOCATION=	properties.getProperty("CHROME_DRIVER_LOCATION");
		Constants.FIREFOX_DRIVER_LOCATION=properties.getProperty("FIREFOX_DRIVER_LOCATION");
		Constants.EDGE_DRIVER_LOCATION=properties.getProperty("EDGE_DRIVER_LOCATION");
		Constants.USERPHONENUMBER=properties.getProperty("USERPHONENUMBER");
		Constants.OTP=properties.getProperty("OTP");

	}
	
	public static void initWebElements() {
		PageFactory.initElements(DriverManager.getDriver(), SignupPageLocators.getInstance());
		PageFactory.initElements(DriverManager.getDriver(),StudentBookingclassLocators.getInstance());
		PageFactory.initElements(DriverManager.getDriver(),StudentSignup_Locators.getInstance());
		PageFactory.initElements(DriverManager.getDriver(),TeacherSignup_Locators.getinstance());
		PageFactory.initElements(DriverManager.getDriver(),TeacherProfile_Locators.getInstance());
		PageFactory.initElements(DriverManager.getDriver(),TeacherScheduleClass_Locators.getInstance());
		
		
		
		
	}
	
	public void takeScreenshot( ) {
		
		File  screenshot=((TakesScreenshot)DriverManager.getDriver()).getScreenshotAs(OutputType.FILE);
		
		//Copy the file to a location and use to try catch block to handle exception
		try {
			org.apache.commons.io.FileUtils.copyFile(screenshot,new File(Whaot_Common_Step_Definations.getScenarioName()+".png"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
	}
	     public void highlightElement(WebElement element) {	
		  JavascriptExecutor executor=(JavascriptExecutor) DriverManager.getDriver();
		  executor.executeScript("arguments[0].setAttribute('style','border:3px solid blue'};", element);
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}


