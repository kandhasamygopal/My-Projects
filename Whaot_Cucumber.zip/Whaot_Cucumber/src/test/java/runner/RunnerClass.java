package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\resources\\features\\whaot_login.feature", 
glue = {"StepDefinations"}, 
		 dryRun= false ,	
		 monochrome=true,
		 plugin= { "html:reports/webreport.html" , "json:reports/jsonreport.json" }
		
		)


public class RunnerClass {

	// it should combine feature file and step defination
	// Runner define

}
