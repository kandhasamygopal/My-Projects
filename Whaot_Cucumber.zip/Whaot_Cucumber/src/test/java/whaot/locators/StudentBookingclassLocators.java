package whaot.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StudentBookingclassLocators {
	
	
	private static StudentBookingclassLocators StudentbookingInstance;
	
	private StudentBookingclassLocators() {
		
	}
	
	public static  StudentBookingclassLocators getInstance() {
		if(StudentbookingInstance==null) {
			StudentbookingInstance=new StudentBookingclassLocators();
		}
		return StudentbookingInstance;
		}
			
	
	
	
	@FindBy(xpath=("//*[@id='content']/section[4]/div[2]/div/div/div/div[1]/div/div/div/img"))
	private  WebElement Scheduleclass_click;
	
	@FindBy(xpath=("//*[@id='content']/div[3]/div/div/button"))
	private  WebElement Book_this_class;
	
	@FindBy(xpath=("//*[@id='content']/div[2]/div/div/div/span"))
	private  WebElement Clicktoaddnewclass;
	
	
	
	@FindBy(className = ("edit-slot-button"))
	private  WebElement pickslot;
	
	@FindBy(xpath =("//div[@class='react-datepicker__month']//div[@class= 'react-datepicker__week']//div[@aria-disabled='false'][contains(.,'')]"))
	private  WebElement Choosedate;
	
	@FindBy(xpath = ("//div[@class='slot-picker-container']//div [position()]//label[contains(.,'')]"))
	private  WebElement choosetime;
	
	@FindBy(xpath = ("//div[@class='slot-picker-container']//div[position()= '2']"))
	private  WebElement Secondchoosetime;
	
	@FindBy(xpath  = ("//div[@class='col-lg-12']//div//div//p[@class='edit-slot-button'][normalize-space()='Edit']"))
	private  WebElement Edit_thetime_pickslot;
	
	@FindBy(xpath = ("//*[@id='booking-payment-detail-modal']/div/div/div[1]/div/div[2]/div[2]/button"))
	private WebElement Savedatetime;
	
	@FindBy(xpath = ("//*[@id='content\']/div[2]/div/button"))
	private WebElement ReviewBooking;
	
	
	@FindBy(xpath= ("//*[@id='review-modal']/div/div/div[2]/div/div[3]/div[2]/div[7]/button"))
	private  WebElement Proceedtopay;
	
	
	@FindBy(xpath= ("//iframe[@class='razorpay-checkout-frame']"))
	private  WebElement razorpaycheckoutframe;
	
	
	@FindBy(xpath= ("//*[@id='form-common']/div[1]/div[1]/div/div/div[2]/div/button[1]"))
	private  WebElement cardpayment;
	
	@FindBy(xpath=("//*[@id='card_number']")) 
	private  WebElement Entercardnumber;
	
	@FindBy(xpath= ("//*[@id='card_expiry']"))
	private  WebElement CardExpiry;
	
	@FindBy(xpath= ("//*[@id='card_cvv']"))
	private  WebElement CVVDetail;
	
	@FindBy(id= ("redesign-v15-cta"))
	private WebElement Pay;
	
	@FindBy(xpath= ("//*[@id='overlay']/div/div/button[2]"))
	private  WebElement PayCardskip;
	
	@FindBy(xpath= ("//*[@class='success']"))
	private  WebElement Success;
	
	@FindBy(xpath= ("//*[@id='booking-success-modal']/div/div/div[1]/div/div[2]/button"))
	private  WebElement okay;

	
	
	public void Scheduleclass_click() {
		
		Scheduleclass_click.click();
	}

	public  void Book_this_class() {
		Book_this_class.click();
	}

	public  void Clickaddnewclass() {
		Clicktoaddnewclass.click();
	}

	public  void ClickPickslot() {
		pickslot.click();
	}

	public  void Choosedate(String date) {
		 Choosedate.sendKeys(date);
		 Choosedate.click();
	}
	
	public  void ChoosedateClick() {
	   Choosedate.click();
	}

	public void Choosetime(String time) {
		choosetime.sendKeys(time);
		
	}

	public  void Secondchoosetime(String secondtime) {
		Secondchoosetime.sendKeys(secondtime);
	}

	public  void Edit_thetime_pickslot() {
		Edit_thetime_pickslot.click();
	}

	public  void Savedatetime() {
		Savedatetime.click();
	}

	public  void ReviewBooking() {
		ReviewBooking.click();
	}

	public void Proceedtopay() {
		Proceedtopay.click();
	}

	public WebElement Razorpaycheckoutframe() {
		return razorpaycheckoutframe;
	}

	public void Cardpayment() {
		 cardpayment.click();;
		
	}

	public void Entercardnumber(String carddetails) {
		Entercardnumber.sendKeys(carddetails);
	}

	public void CardExpiry(String cardexpirydetail) {
		CardExpiry.sendKeys(cardexpirydetail);
	}

	public void CVV_Collected(String EnterCVV) {
		CVVDetail.sendKeys(EnterCVV);
	}

	public void getPay() {
		Pay.click();
	}

	public  void getPayCardskip() {
		PayCardskip.click();
	}

	public  void getSuccess() {
		Success.click();
	}

	public void getOkay() {
		okay.click();
	}
	
	


	
}	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


