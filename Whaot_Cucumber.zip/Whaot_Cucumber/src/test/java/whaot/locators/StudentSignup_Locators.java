package whaot.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import whaot_utilitiles.CommonUtils;

public class StudentSignup_Locators {


	private static StudentSignup_Locators Student_SignupInstance;

	private StudentSignup_Locators () {

	}

	public static StudentSignup_Locators getInstance () {

		if(Student_SignupInstance==null) {
			Student_SignupInstance= new StudentSignup_Locators();
		}
		return Student_SignupInstance;



	}


	@FindBy(xpath=("//*[@id='signup-types-modal']/div/div/div[2]/div/div[3]/a"))
	private WebElement signup_button;

	//login into whaot-web

	@FindBy(xpath=("//*[@id='login-modal']/div/div/div[2]/form/div/div/div/input"))
	private WebElement Newuserphonenumber; 


	//proceed button click
	@FindBy(xpath=("//*[@id='login-modal']/div/div/div[2]/form/button"))
	private WebElement ProceedButton;

	//New Student Signup form


	@FindBy(xpath=("//*[@id='signup-types-modal']/div/div/div[2]/div/div[2]/a/span"))
	private WebElement 	Startlearning;

	//Fill the Student signup details


	@FindBy(xpath=("//*[@id='signup-modal']/div/div/div[2]/div[1]/input"))
	private WebElement Enter_StudentName;

	@FindBy(xpath=("//*[@id='signup-modal']/div/div/div[2]/div[2]/input"))
	private WebElement EnterStudent_Email;


	@FindBy(xpath="//*[@id='signup-modal']/div/div/div[2]/div[6]/input")
	private WebElement EnterStudent_Password;


	@FindBy(xpath=("//*[@id='signup-modal']/div/div/div[2]/div[8]/button"))
	private WebElement Register_student;

	//	New Student send OTP
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[1]"))
	private WebElement Verify_OTP1;

	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[2]"))
	private WebElement Verify_OTP2;

	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[3]"))
	private WebElement Verify_OTP3;

	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[4]"))
	private WebElement Verify_OTP4;

	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/button"))
	private WebElement Submit;

	//choose interest page student choose most three interest


//
//	By interest1 = By.xpath("//*[@id='root']/div/div/div/div[2]/div[1]/label/span/img");
//
//
//	By interest2 = By.xpath("//*[@id='root']/div/div/div/div[2]/div[2]/label/span/img");
//
//
//	By interest3 = By.xpath("//*[@id='root']/div/div/div/div[2]/div[3]/label/span/img");
//
//

	@FindBy(xpath=("//*[@id='root']/div/div/div/div[3]/button"))
	private WebElement saveandproceed;

	public void Signup_button() {
//		CommonUtils.getInstance().highlightElement(signup_button);
		signup_button.click();
	}


	public void getNewuserphonenumber(String phonenumber) {

		Newuserphonenumber.sendKeys(phonenumber);
	}


	public void ProceedButton() {
//		CommonUtils.getInstance().highlightElement(ProceedButton);
		ProceedButton.click();
	}


	public void ClickStartlearning() {
//		CommonUtils.getInstance().highlightElement(Startlearning);
		Startlearning.click();
	}


	public void Enter_StudentName(String studentname) {
		Enter_StudentName.sendKeys(studentname);
	}


	public void EnterStudent_Email(String studentemail) {
		EnterStudent_Email.sendKeys(studentemail);
	}

	public void EnterStudent_Password(String password) {
		EnterStudent_Password.sendKeys(password);
	}


	public void Register_Student() {
//		CommonUtils.getInstance().highlightElement(Register_student);
		Register_student.click();
	}


	public void Verify_OTP1(String OTP1) {
//		CommonUtils.getInstance().highlightElement(Verify_OTP1);
		Verify_OTP1.sendKeys(OTP1);
	}



	public void Verify_OTP2(String OTP2) {
//		CommonUtils.getInstance().highlightElement(Verify_OTP2);
		Verify_OTP2.sendKeys(OTP2);
	}


	public void Verify_OTP3(String OTP3) {
//		CommonUtils.getInstance().highlightElement(Verify_OTP3);
		Verify_OTP3.sendKeys(OTP3);
	}


	public void Verify_OTP4(String OTP4) {
//		CommonUtils.getInstance().highlightElement(Verify_OTP4);
		Verify_OTP4.sendKeys(OTP4);
	}


	public void ContiunetoHomepage() {
		
		Submit.click();
	}

//	WebDriver driver= DriverManager.getDriver();
//
//
//	public  void chosseinterest1() {
//
//
//
//		try {
//			driver.findElement(interest1).click();
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//
//	}
//
//	public void chosseinterest2() {
//		try {
//			driver.findElement(interest2).click();
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//	}
//
//	public void chosseinterest3() {
//		try {
//			driver.findElement(interest3).click();
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//	}
//	public void saveandProceed() {
//		saveandproceed.click();
//	}



}






















