package whaot.locators;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TeacherProfile_Locators {
	
	
	private static TeacherProfile_Locators TeacherProfileInstance;
	
	private TeacherProfile_Locators() {
		
	}
	
	public static TeacherProfile_Locators getInstance() {
		
		if(TeacherProfileInstance==null) {
			TeacherProfileInstance=new TeacherProfile_Locators();
		}
		return TeacherProfileInstance;
		
		
	}
	
	
	
	
	
	
	@FindBy(xpath = "//*[@id='root']/div/div/div/div[1]/div/div[2]/a")
	private WebElement NextButton;

	@FindBy(xpath = "//*[@class='btnOne btn ml-4']")
	private WebElement AgreeContinue;


	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div[1]/div/div[2]/div[2]/div/div[2]/div/input")
	private WebElement Uploadphoto; 
	
	
	@FindBy(xpath = "//*[@id='crop-modal']/div/div/div[3]/button")
	private WebElement cropphotoupload; 

	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div[1]/div/form/div[3]/div[2]/div/div/div/div[1]/div[1]")
	private WebElement Chooselanuguage;

	@FindBy(xpath = "//div[@class=' css-26l3qy-menu']//div[@class=' css-11unzgr']//div")
	private WebElement Hindi;

	@FindBy(xpath = "//*[@class='btnOne ']")
	private WebElement ContinueNext;

	@FindBy(xpath ="//ul[@class='chosen-choices']")
	private WebElement Specialize;
	
	
	@FindBy(xpath = "//ul[@class='chosen-results']//li")
	private WebElement ChosseSpecialize;
	

	@FindBy(xpath = "//div[@class='tags-inner']//ul/li")
	private WebElement AddTopics;

	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div[1]/div/div[3]/div[2]/div/div/div[2]/div[2]/span")
	private WebElement verifyexpertise;

	@FindBy(xpath = "//*[@id='work-experience-form-modal']/div/div/div[2]/form/div[1]/input")
	private WebElement Addexpertisetitle;

	@FindBy(xpath =  "//*[@id='work-experience-form-modal']/div/div/div[2]/form/div[2]/input")
	private WebElement AddexpertiseDescription;


	@FindBy(xpath =  "//*[@id='work-experience-form-modal']/div/div/div[2]/form/div[4]/input")
	private WebElement AddExpertiseURL;


	@FindBy(xpath =  "//*[@id='work-experience-form-modal']/div/div/div[2]/form/div[7]/button")
	private WebElement SaveExpertiseDocument;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div[1]/div/div[4]/div/div/button[2]")
	private WebElement Continueintrovideouploadedpage;


	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div[1]/div/div[2]/div[2]/div/div[2]/div[2]/div/div")
	private WebElement IntroVideo;
	
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div[1]/div/div[2]/div[2]/div/div[3]/div[2]/div/div/div/input")
	private WebElement IntroVideouploaded60secsvideo;

	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div[1]/div/div[5]/div[2]/div/div/div/button")
	private WebElement Verifymyidentity;

	@FindBy(xpath = "//*[@id='recorder-modal']/div/div/div[2]/div/div[2]/div/button")
	private WebElement TurnONmycamara;
	
	//*[@id="recorder-modal"]/div/div/div[2]/div/div[2]/div/div/div[2]/button
	
	@FindBy(xpath = "//div[@class='record-button__ButtonBorder-sc-1n5amwk-2 fFdAUW']")
	private WebElement Recorderbuttonclick;

	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div[1]/div/div[6]/div/div/button[2]")
	private WebElement Goodtogo; 
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/div/div/div[2]/div/div[11]/div/div/button[2]")
	private WebElement Finalreview;
	

	public void getNextButton() throws InterruptedException {
		Thread.sleep(1000);
		NextButton.click();
	}

	public void getAgreeContinue() throws InterruptedException {
		Thread.sleep(1000);
		AgreeContinue.click();
	}

	public void getUploadphoto(String teacherphoto) throws InterruptedException {
		Thread.sleep(1000);
		Uploadphoto.sendKeys(teacherphoto);
	}
	
	public void CropPhotoUpload() throws InterruptedException {
		Thread.sleep(1000);
		cropphotoupload.click();
	}

	public void getChooselanuguage() {
		Chooselanuguage.click();;
	}

	public void getHindi(String languages) {
		Hindi.sendKeys(languages);
	}

	public void getContinueNext() throws InterruptedException {
		Thread.sleep(1000);
		ContinueNext.click();
	}

	public void getSpecialize() throws InterruptedException {
	 Thread.sleep(1000);
     Specialize.click();
    
	}
	public void getchooseSpecialize() throws InterruptedException {
		Thread.sleep(1000);
		ChosseSpecialize.click();
		}

	public void  AddTopics() throws InterruptedException {
		Thread.sleep(1000);
		AddTopics.findElements(By.xpath("//div[@class='tags-inner']//ul/li"));
		
	}

	public void getVerifyexpertise() throws InterruptedException {
			verifyexpertise.click();
	}

	public void getAddexpertisetitle(String addExpertisetitle) throws InterruptedException {
		Thread.sleep(1000);
		Addexpertisetitle.sendKeys(addExpertisetitle);
	}

	public void getAddexpertiseDescription(String addexpertiseDescription) throws InterruptedException {
		Thread.sleep(1000);
		 AddexpertiseDescription.sendKeys(addexpertiseDescription);
	}

	public void getAddExpertiseURL(String addExpertiseURL) throws InterruptedException {
		Thread.sleep(1000);
		AddExpertiseURL.sendKeys(addExpertiseURL);
	}

	public void getSaveExpertiseDocument() throws InterruptedException {
		Thread.sleep(1000);
		SaveExpertiseDocument.click();
	}

	public void getContinueintrovideouploadedpage() throws InterruptedException {
		Thread.sleep(1000);
		Continueintrovideouploadedpage.click();
	}

	public void getIntroVideo() throws InterruptedException {
		Thread.sleep(1000);
		IntroVideo.click();
	}

	public void IntroVideoloaded60secVideo(String introuploadedvideo) throws InterruptedException {
		Thread.sleep(1000);
		IntroVideouploaded60secsvideo.sendKeys(introuploadedvideo);
	}
	
	
	public void getVerifymyidentity() throws InterruptedException {
		Thread.sleep(1000);
		Verifymyidentity.click();
	}

	public void getTurnONmycamara() throws InterruptedException {
		Thread.sleep(1000);
		TurnONmycamara.click();
	}

	public void getRecorderbuttonclick() throws InterruptedException {
		Thread.sleep(1000);
		Recorderbuttonclick.click();
	}

	public void getGoodtogo() throws InterruptedException {
		Thread.sleep(26000);
		Goodtogo.click();
	}

	public void getFinalreview() throws InterruptedException {
		Thread.sleep(1000);
		Finalreview.click();
	}

	
	

}
