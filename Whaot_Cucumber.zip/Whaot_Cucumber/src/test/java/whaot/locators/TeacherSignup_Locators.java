package whaot.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TeacherSignup_Locators {
	
	
	private static TeacherSignup_Locators TeacherSignupInstance;
	
	private  TeacherSignup_Locators() {
		
	}
	public static TeacherSignup_Locators getinstance() {
		
		
		if(TeacherSignupInstance==null) {
		TeacherSignupInstance= new TeacherSignup_Locators();
		
	}
	return TeacherSignupInstance;
	
	}
	
	
	@FindBy(xpath=("//*[@id='signup-types-modal']/div/div/div[2]/div/div[3]/a"))
	private WebElement signup_button;

	//login into whaot-web

	@FindBy(xpath=("//*[@id='login-modal']/div/div/div[2]/form/div/div/div/input"))
	private WebElement Newteacherphonenumber; 


	//proceed button click
	@FindBy(xpath=("//*[@id='login-modal']/div/div/div[2]/form/button"))
	private WebElement ProceedButton;

	//New Teacher Signup form

	
	@FindBy(xpath=("//*[@id='signup-types-modal']/div/div/div[2]/div/div[1]/a/span"))
	private WebElement 	Become_Guru;

	//Fill the Student signup details

	
	@FindBy(xpath=("//*[@id='signup-modal']/div/div/div[2]/div[1]/input"))
	private WebElement Enter_TeacherName;

	@FindBy(xpath=("//*[@id='signup-modal']/div/div/div[2]/div[2]/input"))
	 private WebElement Enterteacher_Email;
	

	@FindBy(xpath="//*[@id='signup-modal']/div/div/div[2]/div[4]/input")
    private WebElement EnterStudent_Password;


    @FindBy(xpath=("//*[@id='signup-modal']/div/div/div[2]/div[6]/button"))
    private WebElement Register_Teacher;

	//	New Teacher send OTP
    @FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[1]"))
	private WebElement Verify_OTP1;
    
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[2]"))
	private WebElement Verify_OTP2;
	
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[3]"))
	private WebElement Verify_OTP3;
	
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[4]"))
	private WebElement Verify_OTP4;

	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/button"))
	private WebElement Submit;

	public void Signup_button() {
		signup_button.click();
	}

	public void Newteacherphonenumber(String phonenumber) {
		Newteacherphonenumber.sendKeys(phonenumber);
	}

	public void ProceedButton() {
		ProceedButton.click();
	}

	public void Become_Guru() {
		Become_Guru.click();
	}

	public void Enter_TeacherName(String username ) {
		Enter_TeacherName.sendKeys(username);
	}

	public void Enterteacher_Email(String useremail) {
		Enterteacher_Email.sendKeys(useremail);
	}

	public void getEnterStudent_Password(String password) {
		EnterStudent_Password.sendKeys(password);
	}

	public void Register_Teacher() {
		Register_Teacher.click();
	}

	public void Verify_OTP1(String OTP1) {
		Verify_OTP1.sendKeys(OTP1);
	}

	public void Verify_OTP2(String OTP2) {
		Verify_OTP2.sendKeys(OTP2);
	}

	public void Verify_OTP3(String OTP3) {
		Verify_OTP3.sendKeys(OTP3);
	}

	public void Verify_OTP4(String OTP4) {
		Verify_OTP4.sendKeys(OTP4);
	}
	public void Submit() {
		Submit.click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
