package whaot.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SignupPageLocators {

	
	private static SignupPageLocators SignuppageInstance;
	
	private SignupPageLocators() {
		
	}
	
	public static SignupPageLocators getInstance() {
		
		if(SignuppageInstance==null) {
			SignuppageInstance= new SignupPageLocators();
		}
		
		return SignuppageInstance;
		
	}
	




	@FindBy(xpath=("//*[@id='signup-types-modal']/div/div/div[2]/div/div[3]/a"))
	private WebElement signup;

	@FindBy(xpath=("//*[@id='login-modal']/div/div/div[2]/form/div/div/div/input"))
	private WebElement EnterphoneNumber;

	@FindBy(xpath=("//*[@id='login-modal']/div/div/div[2]/form/button"))
	private WebElement LetgoButton;

	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[1]"))
	private WebElement Verify_OTP1;
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[2]"))
	private WebElement Verify_OTP2;
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[3]"))
	private WebElement Verify_OTP3;
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[4]"))
	private WebElement Verify_OTP4;

	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/button"))
	private WebElement Submit;
	
	

	public void  ClickSignup() {
		 signup.click();
	}

	public void EnterphoneNumber(String phonenumber) {
		EnterphoneNumber.sendKeys(phonenumber);;
	}

	public void LetgoButton() {
		 LetgoButton.click();
	}

	public void VerifyOTP1(String OTP1) {
		Verify_OTP1.sendKeys(OTP1);
	}

	public void VerifyOTP2(String OTP2) {
		Verify_OTP2.sendKeys(OTP2);
	}

	public void VerifyOTP3(String OTP3) {
		Verify_OTP3.sendKeys(OTP3);
	}

	public void VerifyOTP4(String OTP4) {
		 Verify_OTP4.sendKeys(OTP4);;
	}

	public void ContinueButtonclick() {
		Submit.click();;
	}
	
	
	




}










