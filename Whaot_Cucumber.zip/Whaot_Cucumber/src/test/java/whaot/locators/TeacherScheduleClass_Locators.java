package whaot.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TeacherScheduleClass_Locators {

	
	private static TeacherScheduleClass_Locators ScheduleClassgetInstance;
	
	private TeacherScheduleClass_Locators() {
		
	}
	
	public static TeacherScheduleClass_Locators getInstance() {
		
		if(ScheduleClassgetInstance==null) {
			ScheduleClassgetInstance=new TeacherScheduleClass_Locators();
		}
		return ScheduleClassgetInstance;
		
	}
	
	
	
	
	@FindBy(xpath=("//*[@id='signup-types-modal']/div/div/div[2]/div/div[3]/a"))
	private WebElement signup;
	
	@FindBy(xpath=("//*[@id='login-modal']/div/div/div[2]/form/div/div/div/input"))
	private WebElement EnterphoneNumber;
	
	@FindBy(xpath=("//*[@id='login-modal']/div/div/div[2]/form/button"))
	private WebElement LetgoButton;
	
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[1]"))
	private WebElement Verify_OTP1;
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[2]"))
	private WebElement Verify_OTP2;
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[3]"))
	private WebElement Verify_OTP3;
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/div/input[4]"))
	private WebElement Verify_OTP4;
	
	@FindBy(xpath=("//*[@id='otpModal']/div/div/div[2]/form/button"))
	private WebElement Submit;
	
	
	@FindBy(xpath = "//a[normalize-space()='Create a class']")
	private WebElement Createscheduleclass;
	
	@FindBy(xpath = "//input[@name='title']")
	private WebElement Iwillteachyou;
	
	
	@FindBy(xpath = "//span[normalize-space()='Music']")
	private WebElement Choosecategory;
	
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[4]/div[2]/div/div/div/div/div/ul/li/a")
	private WebElement SelectedTopics;
	
	
	
	@FindBy(xpath = "//div[@class='gridUpload']//div[2]//div[1]//div[1]//div[1]//input[1]")
	private WebElement Videocover;
	
	@FindBy(xpath = "//input[@accept='image/*']")
	private WebElement Videothumbinal;
	
	
	@FindBy(xpath = "//*[@id='crop-modal']/div/div/div[3]/button")
	private WebElement VideothumbinalCropUpload;
	
	
	@FindBy(xpath ="//*[@id='root']/div/div/div[2]/div/form/div/div[6]/div[2]/div/div/div[1]/label/span")
	private WebElement Selectlevel;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[7]/div[2]/div/textarea")
	private WebElement ClassDescription;
	
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[8]/div[2]/div/div[1]/textarea")
	private WebElement Agenda;
	

	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[9]/div[2]/div/div[1]/textarea")
	private WebElement Requirements;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[10]/div[2]/div/div/div/div[1]")
	private WebElement Languages;
	

	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[11]/div/div/button")
	private WebElement ContinueNextpage;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[2]/div[2]/div/div[1]/div[1]/label/span")
	private WebElement ChooseDuration;
	
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[3]/div[2]/div/div/div/a")
	private WebElement AddMoreAvailability;
	
	
	@FindBy(xpath = "//input[@placeholder='From Date']")
	private WebElement FromDate;
	
	
	@FindBy(xpath = "//input[@placeholder='To Date']")
	private WebElement ToDate;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[3]/div[2]/div[4]/div/div[1]/label/span")
	private WebElement SelectMonday;
	
	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[3]/div[2]/div[4]//div[2]")
	private WebElement SelectTuesday;
	
	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[3]/div[2]/div[4]//div[3]")
	private WebElement SelectWednesday;
	
	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[3]/div[2]/div[4]//div[4]")
	private WebElement SelectThursday;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[3]/div[2]/div[4]/div/div[5]/label/span")
	private WebElement SelectFriday;
	
	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[3]/div[2]/div[4]//div[6]")
	private WebElement SelectSaturday;
	
	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[3]/div[2]/div[4]//div[7]")
	private WebElement SelectSunday;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[3]/div[2]/div[6]/div[1]/div/span" )
	private WebElement Fromtime;
	
	@FindBy(xpath = "//div[@class='rc-time-picker-panel-combobox']//div[1]//li[contains(.,'11')]")
	private WebElement Timeslot1;
	
	@FindBy(xpath = "//div[@class='rc-time-picker-panel-combobox']//div[2]//li[contains(.,'10')]")
	private WebElement Timeslot2;

	@FindBy(xpath = "(//div[@class='rc-time-picker-panel-inner'])[1]//div//div[position()=3]//li[contains(.,'')]")
	private WebElement Timeslot_AM;
	
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[3]/div[2]/div[6]/div[2]/div/span")
	private WebElement Totime;
	
	
	@FindBy(xpath = "(//span[normalize-space()='Paid class']")
	private static WebElement Paidclass;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[4]/div[2]/div[2]/div[1]/div/input")
	private static WebElement Classcharge;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[4]/div[2]/div[2]/div[2]/div/input")
	private static WebElement offerDiscount;
	
	@FindBy(xpath = "//*[@id='root']/div/div/div[2]/div/form/div/div[5]/div/div/button[2]")
	private static WebElement SecondContiune;
	
	@FindBy(xpath = "//div[@class='col-lg-5']//a[@class='btnOne btn ml-2'][normalize-space()='Publish class']")
	private static WebElement Publishclass;
	
	@FindBy(xpath = "//span[@class='slider round']")
	private static WebElement Activeclass;

	public void getSignup() {
		signup.click();
	}

	public void getEnterphoneNumber(String phonenumber) {
		EnterphoneNumber.sendKeys(phonenumber);
	}

	public void getLetgoButton() {
		LetgoButton.click();
	}

	public void getVerify_OTP1(String OTP1) {
		Verify_OTP1.sendKeys(OTP1);
	}

	public void getVerify_OTP2(String OTP2) {
		Verify_OTP2.sendKeys(OTP2);
	}

	public void getVerify_OTP3(String OTP3) {
		Verify_OTP3.sendKeys(OTP3);
	}

	public void getVerify_OTP4(String OTP4) {
		Verify_OTP4.sendKeys(OTP4);
	}

	public void getSubmit() {
		Submit.click();
	}

	public void getCreatescheduleclass() throws InterruptedException {
		Thread.sleep(1000);
		Createscheduleclass.click();
	}

	public void getIwillteachyou(String Class_title ) throws InterruptedException {
		Thread.sleep(1000);
		Iwillteachyou.sendKeys(Class_title);
	}

	public void getChoosecategory() throws InterruptedException {
		Thread.sleep(1000);
		Choosecategory.click();
	}

	public void getSelectedTopics() throws InterruptedException {
		Thread.sleep(1000);
		SelectedTopics.click();
	}

	public void getVideocover(String upload_60sec_video) throws InterruptedException {
		Thread.sleep(1000);
		Videocover.sendKeys(upload_60sec_video);
	}
	
	public void getVideothumbinal(String upload_a_cover_image) throws InterruptedException {
		Thread.sleep(1000);
		Videothumbinal.sendKeys(upload_a_cover_image);
	}
	public void VideothumbinalCropUpload() throws InterruptedException {
		Thread.sleep(1000);
		VideothumbinalCropUpload.click();
	}
	

	public void getSelectlevel() throws InterruptedException {
		Thread.sleep(3000);
		Selectlevel.click();
	}

	public void getClassDescription(String Class_description) throws InterruptedException {
		Thread.sleep(1000);
		ClassDescription.sendKeys(Class_description);
	}

	public void getAgenda(String agenda) throws InterruptedException {
		Thread.sleep(1000);
		Agenda.sendKeys(agenda);
	}

	public void getRequirements(String Pre_requirements) throws InterruptedException {
		Thread.sleep(1000);
		Requirements.sendKeys(Pre_requirements);
	}

	public void getLanguages() throws InterruptedException {
		Thread.sleep(1000);
		Languages.click();
	}

	public void getContinueNextpage() throws InterruptedException {
		Thread.sleep(1000);
		 ContinueNextpage.click();
	}

	public void getChooseDuration() throws InterruptedException {
		Thread.sleep(1000);
		ChooseDuration.click();
	}

	public void getAddMoreAvailability() throws InterruptedException {
		Thread.sleep(1000);
		AddMoreAvailability.click();
	}

	public void getFromDate(String From_Date) throws InterruptedException {
		Thread.sleep(1000);
		 FromDate.sendKeys(From_Date);
	}

	public void getToDate(String To_Date) throws InterruptedException {
		Thread.sleep(1000);
		ToDate.sendKeys(To_Date);
	}

	public void getSelectMonday() {
		SelectMonday.click();
	}

	public void getSelectTuesday() {
		SelectTuesday.click();
	}

	public void getSelectWednesday() {
		SelectWednesday.click();
	}

	public void getSelectThursday() {
		SelectThursday.click();
	}

	public void getSelectFriday() {
		SelectFriday.click();
	}

	public void getSelectSaturday() {
		SelectSaturday.click();
	}

	public void  getSelectSunday() {
		SelectSunday.click();
	}

	public void getFromtime() throws InterruptedException {
		Thread.sleep(1000);
		Fromtime.click();
	}

	public void getTimeslot1(String Time_slot1 ) throws InterruptedException {
		Thread.sleep(1000);
		Timeslot1.sendKeys(Time_slot1);
		
	}

	public void getTimeslot2(String Time_slot2 ) throws InterruptedException {
		Thread.sleep(1000);
		Timeslot2.sendKeys(Time_slot2);
	
	}

	public void getTimeslot_AM(String Time_am ) throws InterruptedException {
		Thread.sleep(1000);
		Timeslot_AM.sendKeys(Time_am);
		
	}



	public void getTotime() throws InterruptedException {
		Thread.sleep(1000);
		Totime.click();
	}
	public void getTimeslot3(String Time_slot3) throws InterruptedException {
		Thread.sleep(1000);
		
		Timeslot1.sendKeys(Time_slot3);
	}

	public void getTimeslot4(String Time_slot4) throws InterruptedException {
		Thread.sleep(1000);
		Timeslot2.sendKeys(Time_slot4);
	}

	public void getTimeslot_PM(String Time_pm) throws InterruptedException {
		Thread.sleep(1000);
		Timeslot_AM.sendKeys(Time_pm);
	}
	public void getPaidclass() {
		Paidclass.click();
	}

	public void getClasscharge(String class_charges) throws InterruptedException {
		Thread.sleep(1000);
		Classcharge.sendKeys(class_charges);
	}

	public void getOfferDiscount(String offers_Discount) throws InterruptedException {
		Thread.sleep(1000);
		offerDiscount.sendKeys(offers_Discount);
	}

	public void getSecondContiune() throws InterruptedException {
		Thread.sleep(1000);
		SecondContiune.click();
	}

	public void  getPublishclass() throws InterruptedException {
		Thread.sleep(1000);
		Publishclass.click();
	}

	public void getActiveclass() throws InterruptedException {
		Thread.sleep(1000);
		 Activeclass.click();
	}
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
