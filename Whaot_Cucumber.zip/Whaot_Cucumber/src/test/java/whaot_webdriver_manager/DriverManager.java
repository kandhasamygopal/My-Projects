package whaot_webdriver_manager;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
import whaot_constants.Constants;

public class DriverManager {
	
	private static final Logger LOGGER=LogManager.getLogger(DriverManager.class);
	
	private static WebDriver driver=null;
	
	
	
	

	public static void lanuchBrowser() {
		// TODO Auto-generated method stub
		
		
		
		try {
			switch (Constants.BROWSER) {
			case "chrome":
				ChromeOptions optionsC = new ChromeOptions();
				optionsC.addArguments("use-fake-ui-for-media-stream");
				WebDriverManager.chromedriver().setup();
				LOGGER.info("Launching" + Constants.BROWSER);
				driver = new ChromeDriver(optionsC);
				break;
			case "Firefox":
				FirefoxOptions optionsF = new FirefoxOptions();
				optionsF.addArguments("use-fake-ui-for-media-stream");
				WebDriverManager.firefoxdriver().setup();
				LOGGER.info("Launching" + Constants.BROWSER);
				driver = new FirefoxDriver(optionsF);
				break;
			case "Edge":
				EdgeOptions optionsE = new EdgeOptions();
				optionsE.addArguments("use-fake-ui-for-media-stream");
				WebDriverManager.edgedriver().setup();
				LOGGER.info("Launching" + Constants.BROWSER);
				driver = new EdgeDriver(optionsE);
				break;

			default:
				
				System.setProperty(Constants.CHROME_DRIVER,Constants.CHROME_DRIVER_LOCATION);
				LOGGER.info("Launching" + Constants.BROWSER);
			    driver = new ChromeDriver();
				break;
			}
			
			
		} 
		catch (Exception e) {
			
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}


	public static WebDriver getDriver() {
	return driver;
}

}
